﻿using GalaSoft.MvvmLight;
using $safeprojectname$.Navigation;

namespace $safeprojectname$.ViewModel
{
    public class HelpViewModel : ViewModelBase
    {
        IFrameNavigationService _navigationService;
        private string _myProperty = "HelpPageText";
        public string HelpPageText
        {
            get => _myProperty;

            set
            {
                if (_myProperty == value)
                {
                    return;
                }

                _myProperty = value;
                RaisePropertyChanged();
            }
        }

        public HelpViewModel(IFrameNavigationService navigationService)
        {
            _navigationService = navigationService;
        }
    }
}
