﻿using GalaSoft.MvvmLight.Views;

namespace $safeprojectname$.Navigation
{
    public interface IFrameNavigationService : INavigationService
    {
        object Parameter { get; }
    }
}
